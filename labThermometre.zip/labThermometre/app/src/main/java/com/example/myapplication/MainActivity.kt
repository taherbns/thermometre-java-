package com.example.myapplication

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var manager: SensorManager
    private var tempSensor: Sensor? = null
    private lateinit var t: Thermometre

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        t = Thermometre(this, null)
        setContentView(t)

        manager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        tempSensor = manager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)

        tempSensor?.let {
            manager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        } ?: Toast.makeText(this, "Capteur de température introuvable", Toast.LENGTH_LONG).show()
    }

    override fun onSensorChanged(sensorEvent: SensorEvent) {
        t.setTemp(sensorEvent.values[0])
    }

    override fun onAccuracyChanged(sensor: Sensor, i: Int) {

    }

    override fun onPause() {
        super.onPause()

        manager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()

        manager.unregisterListener(this)
    }
}
