package com.example.myapplication

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.AttributeSet
import android.view.View

class Thermometre(context: Context, attrs: AttributeSet?) : View(context, attrs), SensorEventListener {

    private var temp: Float = 23.0f * 10
    private val sensorManager: SensorManager
    private val temperatureSensor: Sensor?

    init {
        init()
        // initialiser Sensormanager
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        // verifie si le capteur de temperature est disponible
        temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
        // enregitrer le capteur sil est disponible
        temperatureSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)

        }
    }

    private fun init() {
        temp = 23.0f * 10
    }
    override fun onSensorChanged(event: SensorEvent) {
        // mettre a jour la temperature lorsque la valeur du capteur change
        if (event.sensor.type == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            setTemp(event.values[0])
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    fun setTemp(temp: Float) {
        this.temp = temp * 100
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val linePaint = Paint()
        linePaint.color = Color.RED
        linePaint.strokeWidth = 20.0f //  la largeur de segment

        val circlePaint = Paint()
        circlePaint.color = Color.RED

        val gradPaint = Paint()
        gradPaint.color = Color.RED
        gradPaint.strokeWidth = 15.0f // la largeur des graduations

        val textPaint = Paint()
        textPaint.textSize = 40.0f
        textPaint.textAlign = Paint.Align.CENTER

        val centerX = (width / 2).toFloat()
        val centerY = (height - 60.0f).toFloat()

        val bottomY = height.toFloat()
        val graduationHeight = 185.0f // hauteur de graduation dans le segment
        val separation = 50.0f //  valeur pour ajuster la separation

        // lespace entre chaque etiquette
        val labelSpacing = (bottomY - centerY) / 10

        // dessiner les graduations et les etiquettes pour celsius a droite
        for (i in 0..100 step 10) {
            val gradY = bottomY - ((i - 0) * (graduationHeight / 10))
            if (gradY >= 0 && gradY <= bottomY) {
                canvas.drawLine(centerX - separation, gradY, centerX + separation, gradY, gradPaint)

                //etiquettes de texte
                val textX = centerX + separation + 20.0f
                val textY = gradY + labelSpacing
                canvas.drawText("$i°C", textX + 30, textY, textPaint)
            }
        }

// Dessiner les graduations et les etiquettes pour Fahrenheit a gauche
        for (i in 0..100 step 10) {
            val celsiusValue = i
            val fahrenheitValue = (celsiusValue * 9 / 5) + 32
            val gradY = bottomY - ((i - 0) * (graduationHeight / 10))
            if (gradY >= 0 && gradY <= bottomY) {
                canvas.drawLine(centerX - separation, gradY, centerX + separation, gradY, gradPaint)

                // etiquettes de texte
                val textX = centerX - separation - 20.0f
                val textY = gradY + labelSpacing
                canvas.drawText("$fahrenheitValue°F", textX - 70, textY, textPaint)
            }
        }

        //  afficher  temperature
        val tempCelsius = temp / 10 // Convertion en Celsius
        val tempFahrenheit = (tempCelsius * 9 / 5) + 32 // Convertion en  Fahrenheit
        val displayText = "$tempCelsius°C / $tempFahrenheit°F"
        canvas.drawText(displayText, centerX, centerY - 2000.0f, textPaint)

        // dessiner la ligne rouge
        val lineStartY = centerY - temp
        val lineEndY = 100.toFloat() // point final de la ligne
        canvas.drawLine(centerX, lineStartY + 200, centerX, lineEndY - 100, linePaint)

        // dessiner le cercle
        canvas.drawCircle(centerX, centerY, 60.0f, circlePaint)

        // dessiner F
        val fTextX = centerX + separation + 80.0f
        val fTextY = centerY + -1020.0f
        textPaint.color = Color.GRAY
        canvas.drawText("C°", fTextX+150, fTextY, textPaint)

        // dessiner C
        val cTextX = centerX - separation - 80.0f
        val cTextY = centerY + -1020.0f
        textPaint.color = Color.GRAY
        canvas.drawText("F°", cTextX-150, cTextY, textPaint)
    }

    // desenregistrer le capteur lorsque la vue est detachee
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        sensorManager.unregisterListener(this)
    }
}
